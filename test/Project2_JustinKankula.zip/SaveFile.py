s_player3 = 0
s_player = 7
s_enemy = 1
